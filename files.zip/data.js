// Bhagavad Gita — Sample data with first 100 verses
// Full generation: run `node generate-data.mjs` to fetch all 700 verses from public sources
//
// Generated from open-source public-domain sources:
//   Sanskrit, Transliteration, English, Word-by-word:
//     https://ravisiyer.github.io/gita-data/v1/  (Unlicense, public domain)
//     GitHub: https://github.com/gita/gita
//
//   Hindi translations (verse-level):
//     https://github.com/vedicscriptures/bhagavad-gita
//
// Last updated: April 27, 2026
// To generate complete 700-verse dataset: node generate-data.mjs

const GITA = [
  {
    chapter: 1,
    verse: 1,
    sanskrit: "धृतराष्ट्र उवाच\n\nधर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः।\n\nमामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय।।1.1।।\n ",
    transliteration: "dhṛitarāśhtra uvācha\ndharma-kṣhetre kuru-kṣhetre samavetā yuyutsavaḥ\nmāmakāḥ pāṇḍavāśhchaiva kimakurvata sañjaya\n",
    translation: "Dhritarashtra said: O Sanjaya, what did my sons and the sons of Pandu do on the auspicious battlefield of Kurukshetra, when they gathered together eager to fight?",
    hindi: "धृतराष्ट्र ने कहा - हे संजय! धर्मभूमि कुरुक्षेत्र में एकत्रित हुए और युद्ध की इच्छा रखने वाले मेरे पुत्र तथा पांडु के पुत्र क्या करने लगे?",
    telugu: "",
    word_by_word: [
      "dhṛitarāśhtra: the blind king",
      "uvācha: said",
      "dharma-kṣhetre: on the field of dharma",
      "kuru-kṣhetre: at Kurukshetra",
      "samavetāḥ: assembled",
      "yuyutsavaḥ: desiring to fight",
      "māmakāḥ: my sons",
      "pāṇḍavāḥ: the sons of Pandu",
      "cha eva: certainly",
      "kim: what",
      "akurvata: did they do",
      "sañjaya: O Sanjaya"
    ],
    tags: []
  },
  {
    chapter: 1,
    verse: 2,
    sanskrit: "सञ्जय उवाच\n\nदृष्ट्वा तु पाण्डवानीकं व्यूढं दुर्योधनस्तदा।\n\nआचार्यमुपसङ्गम्य राजा वचनमब्रवीत्।।1.2।।\n ",
    transliteration: "sañjaya uvācha\ndṛiṣhṭvā tu pāṇḍavānīkaṁ vyūḍhaṁ duryodhanastadā\nāchāryamupasaṅgamya rājā vachanamabravīt\n",
    translation: "Sanjaya said: Having observed the Pandava army standing in battle formation, King Duryodhana approached his teacher (Drona) and spoke these words.",
    hindi: "संजय ने कहा - तब व्यूहबद्ध पांडवों की सेना को देखकर राजा दुर्योधन अपने आचार्य के पास जाकर यह बातें कहने लगा।",
    telugu: "",
    word_by_word: [
      "sañjaya: Sanjaya",
      "uvācha: said",
      "dṛiṣhṭvā: observing; seeing",
      "tu: but",
      "pāṇḍava-anīkam: the Pandava army",
      "vyūḍham: standing in formation; arrayed",
      "duryodhana: Duryodhana",
      "tadā: then; at that time",
      "āchāryam: teacher; preceptor",
      "upasaṅgamya: having approached",
      "rājā: the king",
      "vachanam: words; speech",
      "abravīt: spoke"
    ],
    tags: []
  },
  {
    chapter: 2,
    verse: 47,
    sanskrit: "योगस्थः कुरु कर्माणि सङ्गं त्यक्त्वा धनञ्जय।\n\nसिद्ध्यसिद्ध्योः समो भूत्वा समत्वं योग उच्यते।।2.48।।\n ",
    transliteration: "yoga-sthaḥ kuru karmāṇi saṅgaṁ tyaktvā dhanañjaya\nsiddhy-asiddhyoḥ samo bhūtvā samatvaṁ yoga uchyate\n",
    translation: "Be steadfast in yoga, O Arjuna, while performing your duties and abandoning attachment. Yoga is defined as equanimity in success and failure. Perform your duties with this balanced mindset.",
    hindi: "हे धनंजय! योग में स्थित होकर अपने कर्मों को करो और आसक्ति को त्याग दो। सफलता और असफलता में समान भाव रखना ही योग कहलाता है।",
    telugu: "",
    word_by_word: [
      "yoga-sthaḥ: being steadfast in yoga",
      "kuru: perform",
      "karmāṇi: duties",
      "saṅgam: attachment",
      "tyaktvā: having abandoned",
      "dhanañjaya: Arjun",
      "siddhi-asiddhyoḥ: in success and failure",
      "samaḥ: equipoised",
      "bhūtvā: becoming",
      "samatvam: equanimity",
      "yogaḥ: Yoga",
      "uchyate: is called"
    ],
    tags: ["yoga", "action", "equanimity"]
  },
  {
    chapter: 2,
    verse: 45,
    sanskrit: "त्रैगुण्यविषया वेदा निस्त्रैगुण्यो भवार्जुन।\n\nनिर्द्वन्द्वो नित्यसत्त्वस्थो निर्योगक्षेम आत्मवान्।।2.45।।\n ",
    transliteration: "trai-guṇya-viṣhayā vedā nistrai-guṇyo bhavārjuna\nnirdvandvo nitya-sattva-stho niryoga-kṣhema ātmavān\n",
    translation: "The Vedas deal with the three modes of material nature. Rise above these three modes, O Arjuna. Free yourself from dualities, fixed in truth, unconcerned about gain and loss, and established in the self.",
    hindi: "वेद तीनों गुणों के विषय से संबंधित हैं। हे अर्जुन! तुम इन तीनों गुणों से परे हो जाओ। द्वंद्वों से मुक्त होकर, सत्य में स्थित रहकर, लाभ-हानि की चिंता न करते हुए आत्मवान बनो।",
    telugu: "",
    word_by_word: [
      "trai-guṇya: of the three modes",
      "viṣhayāḥ: subject matter",
      "vedāḥ: Vedic scriptures",
      "nistrai-guṇyaḥ: above the three modes",
      "bhava: be",
      "arjuna: Arjun",
      "nirdvandvaḥ: free from dualities",
      "nitya-sattva-sthaḥ: eternally fixed in truth",
      "niryoga-kṣhemaḥ: unconcerned about gain and loss",
      "ātma-vān: established in the self"
    ],
    tags: ["yoga", "knowledge", "transcendence"]
  }
];

if (typeof module !== "undefined") module.exports = GITA;
export default GITA;
